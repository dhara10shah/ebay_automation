Info about project

Pre-req:
Maven installed
Chrome browser installed
Firefox installed
Java installed

Framework :TestNg, Selenium
Language: JAVA(1.8)
Build Tool:Maven
Design pattern:page object model

Features:
Genearate log file
Log files will be found under
.\eBay\log folder

